#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<string.h>

/* 構造体宣言 */
//社員構造体
struct entry {
    char id[5];
    char name[20];
    int sex;
    char department[10];
    char my_intro[100];
    //struct entry *next_cell;
};

//リスト構造体
struct cell{
    struct entry cell_entr;
    struct cell *next_cell;
};



/* 広域変数宣言 */
struct cell list_head = {0 ,0};
struct cell *p_list_head = &list_head;
FILE *fp;
char filename[100];


/* デモデータ */
struct entry entry_1 = { "111", "arinaga", 0, "IIS-E2", "I am King."};
struct entry entry_2 = { "112", "kuroiwa", 1, "IIS-E1", "I am Queen."};
struct entry entry_3 = { "113", "Mita", 1, "IIS-E1", "I am Jack."};


int main(void){
    //char filename[100]; 
    char *p_filename;
    p_filename = filename;

    /* main関数内デモ 
    list_head -> cell_1 -> cell_2 -> cell_3　
    ※cell_3のnext_cellはNULL
    ※list_headの中身　→{0, cell_1}
    */
   /* 以下のコードはmain関数内に記述してください */
    struct cell *cell_1 = NULL;
    struct cell *cell_2 = NULL;
    struct cell *cell_3 = NULL;

    cell_1 = (struct cell*)malloc(sizeof(struct cell));
    cell_1->cell_entr = entry_1;
	p_list_head->next_cell = cell_1;

	cell_2 = (struct cell*)malloc(sizeof(struct cell));
    cell_2->cell_entr = entry_2;
    cell_1->next_cell = cell_2;

	cell_3 = (struct cell*)malloc(sizeof(struct cell));
    cell_3->cell_entr = entry_3;
    cell_2->next_cell = cell_3;

    cell_3->next_cell = NULL;





    
    printf("%s,%s\n",cell_3->cell_entr.id,cell_3->cell_entr.name);
    /*main関数内デモ終端*/

    FILE *lf;
    lf = fopen("sample.bin","wb");

    if(lf == NULL){
        printf("該当するファイルはありません\n");
        exit(EXIT_FAILURE);
    };

    fwrite(&cell_1->cell_entr,sizeof(cell_3),1,lf);
    //while((ch = fgetc(pf)) != EOF){
        //mainlist = addlist(mainlist,ch);
        //printf("%c",ch);

    


    //}
    fclose(lf);
    

    printf("表示したいファイル名を入力してください\n");
    scanf("%s",p_filename);
    file_load(p_filename);

}


void file_load(char *p_filename){
    FILE *pf;
    //char ch;
    struct cell *cell_4 = NULL;
    cell_4 = (struct cell*)malloc(sizeof(struct cell));

    printf("%s\n",p_filename);

    pf = fopen(p_filename,"rb");

    if(pf == NULL){
        printf("該当するファイルはありません\n");
        exit(EXIT_FAILURE);
    };

    //while (fread((char *)&cell_4, sizeof(struct cell), 1, pf) != 0) {
        //db_append((struct cell *)&cell_1);
        printf("！！！！！！！！！！！！！！！！！！！！\n");
        fread(&cell_4,sizeof(struct cell),1,pf);
        printf("%s\n",cell_4->cell_entr.id);
        //memcpy((char*)&cell_4->cell_entr, (char*)cell_4,sizeof(struct cell));
        //printf("%s,%s\n",cell_4->cell_entr.id,cell_4->cell_entr.name);
    


    //}
    //while((ch = fgetc(pf)) != EOF){
        //mainlist = addlist(mainlist,ch);
      //  printf("%s",ch);
        //cell_4->cell_entr = ;

    


    //}
    fclose(pf);
    //return 0;

    //put_list(mainlist);
};

/* file_load() : ファイルをロードしてリストに格納する関数 */
//struct cell *file_load(struct cell *p_list_head){
    //int c;

/*
struct cell *file_load(){
    int c;
    FILE *infile = fopen(filename, "rb");
    if (infile == NULL){
        printf("強制終了!\n");
        exit(2);
    }
    printf("ファイルの文字を1文字ずつリストに格納します。");
    struct cell *curr_cell = (struct cell*)p_list_head;
    struct cell *list_end;
    //curr_cell->prev = NULL;
 
    while ((c=fgetc(infile)) != EOF){
        curr_cell = append(c, curr_cell);
        // printf("文字をリストに追加！\n");
    }
    //list_end = curr_cell->prev;
 
    fclose(infile);
    //return list_end;
}


// struct entry* append(char c, struct entry *curr_cell){
//     struct entry *new_cell;
//     /* 記憶領域の確保 */
//     if ((new_cell = (struct entry *) malloc(sizeof(struct entry))) == NULL) {
//         printf("malloc error\n");
//         exit(EXIT_FAILURE);
//     }
 
//     curr_entry->id = id;
//     curr_entry->name = name;
//     curr_entry->sex = sex;
//     curr_entry->department = department;
//     curr_entry->my_intro = my_intro;
//     curr_entry->next = new_cell;
//     new_entry->next = NULL;
//     //new_cell->prev = curr_cell;
//     curr_cell = new_cell;
//     return curr_cell;
// }
